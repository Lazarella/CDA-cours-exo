import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import HomePage from './HomePage.jsx'
import StatefulComponent from './components/StatefulComponent.jsx'
import HookDemoComponent from './components/HookDemoComponent.jsx'
import FormComponent from './components/FormComponent.jsx'
import CartComponent from './components/CartComponent.jsx'
import DisplayProduct from './components/DisplayProduct.jsx'
import ParentComponent from './components/ParentComponent.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    {/* <App />
    <HomePage attrA='titi' attrB='toto' />
    <StatefulComponent />
    <p className='testClasse'>Paragraphe</p>
    <HookDemoComponent>
      <p>Ceci est entre les deux balises</p>
    </HookDemoComponent> */}
    {/* <FormComponent /> */}
    {/* <CartComponent /> */}
    {/* <DisplayProduct /> */}
    <ParentComponent />
  </React.StrictMode>,
)
