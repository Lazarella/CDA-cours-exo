const HomePage = (props) => {
    /* eslint-disable react/prop-types */
    const { attrA, attrB } = props

    const attrBUpper = () => {
        return attrB.toUpperCase()
    }

    return (
        <>
            <p>Home Page</p>
            <hr />
            <span>La valeur de attrA est de <b>{attrA}</b></span> <br />
            <span>La somme de 1 + 8 est de <b>{1 + 8}</b></span> <br />
            <span>La valeur en majuscule de attrB est de <b>{attrBUpper()}</b></span>
        </>
    )
}

export default HomePage