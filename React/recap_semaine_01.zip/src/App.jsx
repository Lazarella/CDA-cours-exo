import { useState } from "react";
import DemoUseEffect from "./components/DemoUseEffect"

function App() {
  const [inputValue, setInputValue] = useState("")
  const sayHello = () => {
    console.log("Bonjour");
  }

  const logInputValue = (event, paramA) => {
    setInputValue(event.target.value)
  }

  return (
    <>
        <p>Paragraphe</p>
        <DemoUseEffect blabla={sayHello} valueA={inputValue} valueInput={logInputValue}/>
    </>
  )
}

export default App
