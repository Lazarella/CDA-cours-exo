import { useState } from "react"
import ChildAComponent from "./ChildAComponent"
import ChildBComponent from "./ChildBComponent"
import { MyContext } from "../contexts/MonContext"

const ParentComponent = () => {
    const [inputValue, setInputValue] = useState("")

    return (
        <>
        <h1>ParentComponent</h1>
        <p>Dans le parent, inputValue vaut: {inputValue}</p>
        <hr />
            <MyContext.Provider value={{inputValue, setInputValue, trucMuche: "Titi"}}>
                <ChildAComponent />
                <ChildBComponent />
            </MyContext.Provider>

            <MyContext.Provider value={{inputValue, setInputValue, trucMuche: "Tata"}}>
                <ChildAComponent />
                <ChildBComponent />
            </MyContext.Provider>
        </>
    )
}

export default ParentComponent