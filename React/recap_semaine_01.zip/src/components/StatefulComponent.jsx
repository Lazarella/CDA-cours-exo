import { PureComponent } from "react";

class StatefulComponent extends PureComponent {
    constructor(props) {
        super(props)
        this.state = {
            valeurInput: "John"
        }

    }
    
    inputChanged (event) {
        this.setState({
            valeurInput: event.target.value
        })
    }

    // componentDidMount

    // shouldComponentUpdate (Pure)
    // componentDidUpdate

    // componentDidCatch

    // componentWillUnmount
    
    render () {
        return (
            <>
                <h1>Stateful Component</h1>
                <input type="text" onInput={this.inputChanged.bind(this)} />
                <hr />
                <p>
                    La valeur de mon input est : <b>{this.state.valeurInput}</b>
                </p>
            </>
        )
    }
}

export default StatefulComponent