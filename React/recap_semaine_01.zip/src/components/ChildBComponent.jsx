import { useContext } from "react"
import { MyContext } from "../contexts/MonContext"

const ChildBComponent = () => {
    const { inputValue, trucMuche } = useContext(MyContext)

    console.log(useContext(MyContext));
    return (
        <>
        <h3>ChildBComponent</h3>
        <p>TrucMuche: {trucMuche}</p>
        <p>Dans l'enfant, la state vaut: {inputValue}</p>
        </>
    )
}

export default ChildBComponent