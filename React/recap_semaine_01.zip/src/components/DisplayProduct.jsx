import { useEffect, useState } from "react"

const sleep = (time) => new Promise(res => setTimeout(res, time * 1000))

const DisplayProduct = () => {
    const [product, setProduct] = useState(null)
    const [loading, setLoading] = useState(true)

    const fetchProduct = async () => {
        setLoading(true)
        await sleep(2)
        setProduct({
            title: "Banane",
            price: 1.29
        })
        setLoading(false)
    }

    useEffect(() => {
        fetchProduct()
    }, [])

    if (loading) {
        return <span>Loading...</span>
    } else {
        return (
            <>
                <div>Title: {product.title}</div>
                <div>Price: {product.price}</div>
            </>
        )
    }

}

export default DisplayProduct