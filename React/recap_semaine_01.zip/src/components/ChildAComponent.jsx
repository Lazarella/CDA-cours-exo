import { useContext } from "react"
import { MyContext } from "../contexts/MonContext"

const ChildAComponent = () => {
    const { inputValue, setInputValue } = useContext(MyContext)
    return (
        <>
        <h3>ChildAComponent</h3>
        <input type="text" value={inputValue} onInput={(e) => setInputValue(e.target.value)} />
        </>
    )
}

export default ChildAComponent