import { useEffect } from "react"

const DemoUseEffect = (props) => {
    const { blabla, valueInput, valueA } = props

    console.log(valueA);

    useEffect(() => {
        console.log("Mounting...");

        return () => {
            console.log("Unmounting...");
        }
    }, [valueA])

    return (
        <>
            <h2>Demo UseEffect</h2>
            <button onClick={blabla}>Click me</button>
            <hr />
            <input type="text" onInput={(e) => valueInput(e, "titi")} />
        </>
    )
}

export default DemoUseEffect