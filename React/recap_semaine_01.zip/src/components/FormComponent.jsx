import { useRef, useState } from "react"

const FormComponent = () => {
    // const [username, setUsername] = useState("")
    // const [password, setPassword] = useState("")
    // const [firstname, setFirstname] = useState("")

    const [form, setForm] = useState({
        username: "",
        password: "",
        firstname: ""
    }) 

    // const usernameInputRef = useRef()
    // const passwordInputRef = useRef()
    // const firstnameInputRef = useRef()

    const submitHandler = (event) => {
        event.preventDefault()

        // const user = {
        //     username: usernameInputRef.current.value,
        //     password: passwordInputRef.current.value,
        //     firstname: firstnameInputRef.current.value
        // }

        console.log(form);
    }

    const handleChanged = (event) => {
        setForm(prevState => ({
            ...prevState,
            [event.target.id]: event.target.value
        }))
    }


    return (
        <form onSubmit={submitHandler}>
            <div>
                <label htmlFor="username">Username:</label>
                <input type="text" id="username" value={form.username} onInput={handleChanged}  />
            </div>
            <div>
                <label htmlFor="password">Password:</label>
                <input type="password" id="password" value={form.password}  onInput={handleChanged} />
            </div>
            <div>
                <label htmlFor="firstname">Firstname:</label>
                <input type="text" id="firstname" value={form.firstname}  onInput={handleChanged} />
            </div>
            <div>
                <button>Submit</button>
            </div>
        </form>
    //     <form onSubmit={submitHandler}>
    //     <div>
    //         <label htmlFor="username">Username:</label>
    //         <input type="text" id="username" ref={usernameInputRef}  />
    //     </div>
    //     <div>
    //         <label htmlFor="password">Password:</label>
    //         <input type="password" id="password" ref={passwordInputRef}  />
    //     </div>
    //     <div>
    //         <label htmlFor="firstname">Firstname:</label>
    //         <input type="text" id="firstname" ref={firstnameInputRef}  />
    //     </div>
    //     <div>
    //         <button>Submit</button>
    //     </div>
    // </form>
    )
}

export default FormComponent