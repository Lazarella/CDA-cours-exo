import { useState } from "react"

const HookDemoComponent = (props) => {
    const [count, setCount] = useState(0)

    const counterIncrement = () => {
        // setCount(count + 1) // 0 => 0 + 1 => 1 
        // setCount(count + 1) // 0 => 0 + 1 => 1 
        // setCount(count + 1) // 0 => 0 + 1 => 1 
        // setCount(count + 1) // 0 => 0 + 1 => 1 
        // setCount(count + 1) // 0 => 0 + 1 => 1 
        
        setCount(prev => prev + 1) // 0 + 1 => 1
        setCount(prev => prev + 1) // 1 + 1 => 2
        setCount(prev => prev + 1) // 2 + 1 => 3
        setCount(prev => prev + 1) // 3 + 1 => 4
        setCount(prev => prev + 1) // 4 + 1 => 5
    }

    return (
        <>
            <button onClick={counterIncrement}>{count}</button>
            {props.children}
        </>
    )
}

export default HookDemoComponent