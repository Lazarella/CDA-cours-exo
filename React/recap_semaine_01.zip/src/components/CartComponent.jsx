import { useState } from "react"

const CartComponent = () => {
    const [count, setCount] = useState(0)
    const [unitPrice, setUnitPrice] = useState(0.0)
    const totalPrice = count * unitPrice
    

    return (
        <>
            <input type="number" min={0.00} max={50.00} step={0.01} value={unitPrice} onInput={(e) => setUnitPrice(e.target.value)}/>
            <button onClick={() => setCount(count + 1)}>Nb Products: {count}</button>
            <span>Total price: {totalPrice}</span>
        </>
    )
}

export default CartComponent