import { createContext } from "react";

export const MyContext = createContext("hello world")